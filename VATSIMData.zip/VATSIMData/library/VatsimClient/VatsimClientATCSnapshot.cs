namespace VatsimLibrary.VatsimClient
{
    public class VatsimClientATCSnapshot
    {
        
    }

}